create function set_updated_at_in_chats() returns trigger
    language plpgsql
as
$$
DECLARE
    lastChatId INTEGER := (SELECT chat_id FROM messages ORDER BY message_id DESC LIMIT 1);
BEGIN
    UPDATE chats SET updated_at = NOW() WHERE chat_id = lastChatId;
    RETURN NEW;
END;
$$;

alter function set_updated_at_in_chats() owner to alexgls;

